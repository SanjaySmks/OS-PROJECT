<?php
$color = array(4 => 'white', 6 => 'green', 11 => 'red');
$first = reset($color);
echo $first;
?>

